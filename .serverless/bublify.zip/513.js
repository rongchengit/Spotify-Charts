"use strict";
exports.id = 513;
exports.ids = [513];
exports.modules = {

/***/ "./src/server/render.tsx":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ render)
});

// EXTERNAL MODULE: ./node_modules/react/index.js
var react = __webpack_require__("./node_modules/react/index.js");
// EXTERNAL MODULE: ./node_modules/react-dom/server.node.js
var server_node = __webpack_require__("./node_modules/react-dom/server.node.js");
// EXTERNAL MODULE: ./node_modules/react-router/dist/index.js
var dist = __webpack_require__("./node_modules/react-router/dist/index.js");
;// CONCATENATED MODULE: ./src/spotifyLogin.ts
//generate random string for authorization token
function generateRandomString(length) {
  let text = '';
  let possible = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  for (let i = 0; i < length; i++) {
    text += possible.charAt(Math.floor(Math.random() * possible.length));
  }
  return text;
}

//makes a hash out of the authorization code using sha256 algorithm
async function generateCodeChallenge(codeVerifier) {
  function base64encode(arrayBuffer) {
    //@ts-ignore
    return btoa(String.fromCharCode.apply(null, new Uint8Array(arrayBuffer))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  }
  const encoder = new TextEncoder();
  const data = encoder.encode(codeVerifier);
  const digest = await window.crypto.subtle.digest('SHA-256', data);
  return base64encode(digest);
}
//the format 
function getTokenSet() {
  return JSON.parse(localStorage.getItem('tokenSet')); //tokenSet
}

function appendUserIdToTokenSet(user_id) {
  const newTokenSet = getTokenSet();
  newTokenSet.user_id = user_id;
  localStorage.setItem('tokenSet', JSON.stringify(newTokenSet));
}
async function authorizeLogin() {
  if (localStorage.getItem('code') && localStorage.getItem('code-verifier')) {
    //if both code and code-verifier are in the authorize login then return that means the person just left the computer on
    const tokenSet = getTokenSet();
    if (tokenSet?.refresh_token && tokenSet.expires_at < Date.now() + 60000) {
      //if we have a refresh token and if its about to expire then refresh the token
      await refreshAccessToken();
    }
    return;
  }
  //if not do all these things
  const clientId = '98d7d7247b8e4cb3a1c7f6257ee1fa61'; //client id non secret decoded
  const redirectUri = 'http://localhost:3000/callback'; //website name

  let codeVerifier = generateRandomString(128);
  generateCodeChallenge(codeVerifier).then(codeChallenge => {
    let state = generateRandomString(16);
    let scope = 'playlist-read-private user-library-read user-follow-read'; //scope for the endpoints to the private data

    let args = new URLSearchParams({
      response_type: 'code',
      client_id: clientId,
      scope: scope,
      //using the scope it gives us access to private playlist
      redirect_uri: redirectUri,
      state: state,
      code_challenge_method: 'S256',
      code_challenge: codeChallenge
    });
    localStorage.setItem('code-verifier', codeVerifier);
    window.location.href = 'https://accounts.spotify.com/authorize?' + args; //location.href  goes to a link
  });
}

async function login() {
  const code_verifier = localStorage.getItem('code-verifier');
  const code = localStorage.getItem('code');
  await createAccessToken({
    grant_type: 'authorization_code',
    code: code,
    redirect_uri: "http://localhost:3000/callback",
    code_verifier: code_verifier
  });
}
function logout() {
  localStorage.removeItem('tokenSet');
  localStorage.removeItem('code');
  localStorage.removeItem('code-verifier');
}

/**
 * @param {Record<string, string>} params
 * @returns {Promise<string>} 
 */

async function createAccessToken(params) {
  const response = await fetch('https://accounts.spotify.com/api/token', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded'
    },
    body: new URLSearchParams({
      client_id: '98d7d7247b8e4cb3a1c7f6257ee1fa61',
      ...params
    })
  });
  if (!response.ok) {
    throw new Error("could not get access token");
  }
  const tokenInfo = await response.json();
  //@ts-ignore
  const accessToken = tokenInfo.access_token;
  //@ts-ignore
  const expires_at = Date.now() + 1000 * tokenInfo.expires_in; //*1000 because it is milliseconds

  localStorage.setItem('tokenSet', JSON.stringify({
    ...tokenInfo,
    expires_at
  }));
  return accessToken;
}
async function refreshAccessToken() {
  const response = await fetch('https://accounts.spotify.com/api/token', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded'
    },
    body: new URLSearchParams({
      grant_type: 'refresh_token',
      //@ts-ignore
      refresh_token: JSON.parse(localStorage.getItem('tokenSet')).refresh_token,
      client_id: '98d7d7247b8e4cb3a1c7f6257ee1fa61'
    })
  });
  if (!response.ok) {
    throw new Error("could not get access token via refresh token");
  }
  const tokenInfo = await response.json();
  //@ts-ignore
  const expires_at = Date.now() + 1000 * tokenInfo.expires_in; //*1000 because it is milliseconds

  localStorage.setItem('tokenSet', JSON.stringify({
    ...tokenInfo,
    expires_at
  }));
}
async function fetchToken() {
  //async function that returns a string which is the access token

  const tokenResponse = await fetch("https://accounts.spotify.com/api/token", {
    //get token from spotify API
    method: "POST",
    //make a post request  to the spotify API
    body: "grant_type=client_credentials",
    //use the grant type client credentials
    headers: {
      //the headers we need to provide content, accept, and authorization
      "Content-Type": "application/x-www-form-urlencoded",
      "Accept": "application/json",
      //only acepts json
      "Authorization": "Basic OThkN2Q3MjQ3YjhlNGNiM2ExYzdmNjI1N2VlMWZhNjE6YWI5NmY2ZjhmYjkxNDFlZGFlMzc0MDg2NDU5ZTMwNDc=" //adding client id and secret as base64 encoded 
    }
  });

  const tokenData = await tokenResponse.json(); // from line 14 get the response and put it in a json object
  localStorage.setItem('tokenSet', JSON.stringify({
    access_token: tokenData.access_token,
    expires_at: Date.now() + 3600000
  })); // have access token and expires in 3600000 which is 1 hour
}

//everytime we need a access token we just call this function
//if login use user token
//and if its not logged in use system token
//it will get it from local storage or from spotify
async function getAccessToken() {
  const tokenSet = getTokenSet();
  if (!tokenSet || !tokenSet.refresh_token && localStorage.getItem('code-verifier')) {
    //if token is not found then login 
    if (!localStorage.getItem('code')?.length && window.location.search.length) {
      //look for the length of the code and it will always be zero instead of null
      //@ts-ignore
      localStorage.setItem('code', new URLSearchParams(window.location.search).get('code'));
    }
    if (!localStorage.getItem("code-verifier") || !localStorage.getItem('code')?.length) {
      //if not logged in, get system token, or if he doesnt have a code then use a token
      await fetchToken();
      return getTokenSet().access_token;
    } else {
      await login();
    }
  } else if (tokenSet.refresh_token && tokenSet.expires_at < Date.now() + 60000) {
    //if we have a refresh token and if its about to expire then refresh the token
    await refreshAccessToken();
  } else if (!tokenSet.refresh_token && tokenSet.expires_at < Date.now() + 60000) {
    //if we call a function and we dont have refresh token and current token is expired and what we do is give system token
    logout();
    await fetchToken();
    return getTokenSet().access_token;
  }
  //@ts-ignore
  return getTokenSet().access_token;
}
function isLoggedIn() {
  const tokenSet = getTokenSet();
  return tokenSet && tokenSet.refresh_token;
}
async function fetchProfile() {
  if (isLoggedIn()) {
    const response = await fetch('https://api.spotify.com/v1/me', {
      headers: {
        Authorization: 'Bearer ' + (await getAccessToken())
      }
    });
    const data = await response.json();
    appendUserIdToTokenSet(data.id);
    return data;
  }
}
function getToken() {}
async function checkLogin(func) {
  if (isLoggedIn()) {
    return await func();
  }
  await authorizeLogin();
}

//in home.tsx go to conditional and if the user is logged add html element p for P<HTML ELEMENT> put the user name in it and its called get profile
// if not do the login button
;// CONCATENATED MODULE: ./src/spotifyUtils.ts

//interface followers

async function fetchUserPlaylists(user_id) {
  //any synchronous function you can use await //its so I dont have to chain //paramenters with user_id//return array of playlist items

  const url = `https://api.spotify.com/v1/users/${user_id}/playlists`; //create the url
  const playlistResponse = await fetch(url, {
    headers: {
      'Authorization': 'Bearer ' + (await getAccessToken()),
      "Content-Type": "application/json",
      "Accept": "application/json"
    }
  }); //get the url and play using bearer token
  const playlistdata = await playlistResponse.json();
  const playlistItems = playlistdata.items;
  if (isLoggedIn()) {
    playlistItems.push({
      id: "likedSongs",
      name: "Liked Songs",
      images: []
    }); //add the playlist items in the new braces
  }

  return playlistdata.items; //grabs the playlist data
}

//TODO: call playlist/playlist_id/tracks instead and add batching with limit = 50
async function fetchPlaylistById(playlist_id) {
  if (playlist_id === "likedSongs") {
    return fetchCurrentUserLikedList();
  }
  const url = `https://api.spotify.com/v1/playlists/${playlist_id}/tracks`; //create the url for playlist by ID
  const token = await getAccessToken();
  const playlistResponse = await fetch(url, {
    headers: {
      'Authorization': 'Bearer ' + token,
      "Content-Type": "application/json",
      "Accept": "application/json"
    }
  }); //get the url and play using bearer token
  const playlists = await playlistResponse.json(); //get response back/ gives all the info about the playlist
  let trackResult = playlists.items; //creates an array with first limit tracks

  if (playlists.total > playlists.limit) {
    const numCalls = Math.ceil((playlists.total - playlists.limit) / playlists.limit); // playlist total(1885) - limit(100) / limit(100) = 17.85 and we want the  ceiling so we want 18 calls = math.ceil
    const urls = []; //create an array for spotify
    for (let i = 1; i <= numCalls; i++) {
      urls.push(url + "?offset=" + i * playlists.limit); //the pla
    }

    const responses = await Promise.all(urls.map(async u => {
      const resp = await fetch(u, {
        headers: {
          'Authorization': 'Bearer ' + token,
          "Content-Type": "application/json",
          "Accept": "application/json"
        }
      });
      return resp.json();
    })); //contains array of call elements and each response contains the entire spotifyCalls returns

    responses.forEach(pr => {
      trackResult = trackResult.concat(pr.items); //this puts all the playlist called together
    });
  }

  return trackResult;
}
async function fetchCurrentUserLikedList() {
  const url = `https://api.spotify.com/v1/me/tracks`; //create the url for current user and get limit which is 50
  const token = await getAccessToken();
  const playlistResponse = await fetch(url + "?limit=50", {
    headers: {
      'Authorization': 'Bearer ' + token,
      "Content-Type": "application/json",
      "Accept": "application/json"
    }
  }); //get the url and play using bearer token and setting the initial limit to 50
  const playlists = await playlistResponse.json(); //get response back/ gives all the info about the playlist
  let trackResult = playlists.items; //creates an array with first limit tracks

  if (playlists.total > playlists.limit) {
    const numCalls = Math.ceil((playlists.total - playlists.limit) / playlists.limit); // playlist total(1885) - limit(100) / limit(100) = 17.85 and we want the  ceiling so we want 18 calls = math.ceil
    const urls = []; //create an array for spotify
    for (let i = 1; i <= numCalls; i++) {
      urls.push(url + "?limit=50&offset=" + i * playlists.limit); //setting the offset and we want to set the limit so ?limit=50&offset= //offset is for looping through the track so it doesnt get the same 50 tracks
    }

    const responses = await Promise.all(urls.map(async u => {
      const resp = await fetch(u, {
        headers: {
          'Authorization': 'Bearer ' + token,
          "Content-Type": "application/json",
          "Accept": "application/json"
        }
      });
      return resp.json();
    })); //contains array of call elements and each response contains the entire spotifyCalls returns

    responses.forEach(pr => {
      trackResult = trackResult.concat(pr.items); //this puts all the playlist called together
    });
  }

  return trackResult;
}
async function fetchArtists(artistIDs) {
  const batchedArtistIDs = splitArrayIntoBatches(artistIDs, 50); //counts to 50 then split, seperating the amount into batches
  let urls = []; //space for url array
  for (let i = 0; i < batchedArtistIDs.length; i++) {
    urls.push(`https://api.spotify.com/v1/artists?ids=${batchedArtistIDs[i].join()}`); //push list of artist ids from 0-49 and appended together into the url array. basically making urls
  }

  const access_token = await getAccessToken();
  const artistResponse = await Promise.all(urls.map(url => fetch(url, {
    headers: {
      'Authorization': 'Bearer ' + access_token,
      "Content-Type": "application/json",
      "Accept": "application/json"
    }
  }))); //fetching multiple times for the promise all response

  let artists = [];
  for (let artist of artistResponse) {
    const a = await artist.json();
    artists.push(...a.artists); //adding the ... takes out all the elements and pushes 1 at a time from 1 array to another, so non nested array resulting in artist in a single array
  }

  return artists;
}
function splitArrayIntoBatches(arr, batchSize) {
  const result = [];
  const length = arr.length;
  let i = 0;
  while (i < length) {
    result.push(arr.slice(i, i + batchSize));
    i += batchSize;
  }
  return result;
}

//can be checked by getPRofile()
//console response to put that info into p element

// async function fetchFollowers = {
//   const url = `https://api.spotify.com/v1/me/following/contains`; //create the url for check If users follows artist or users
//   const token = await getAccessToken();
//   const followerResponse = await fetch(url, {headers: {'Authorization': 'Bearer ' + token, "Content-Type": "application/json","Accept": "application/json"}});//get the url and play using bearer token
//   const followers = await followerResponse.json();
// }
// EXTERNAL MODULE: ./node_modules/d3/src/index.js + 127 modules
var src = __webpack_require__("./node_modules/d3/src/index.js");
;// CONCATENATED MODULE: ./src/bubbleGraph.ts
 //importing everything from d3

function normalizeRadius(value, minValue, maxValue, minRadius, maxRadius) {
  // Check if minValue and maxValue are equal
  if (minValue === maxValue) {
    // Return the average of minRadius and maxRadius
    return (minRadius + maxRadius) / 2;
  }

  // Normalize the input value within the range of minValue to maxValue
  const normalizedValue = (value - minValue) / (maxValue - minValue);
  // Scale the normalized value to the range of minRadius to maxRadius
  const radius = minRadius + normalizedValue * (maxRadius - minRadius);
  return radius;
}
function buildGraph(data, backgroundImageURL, focus) {
  const totalCount = data.reduce((total, next) => total += next.count, 0); //grabbing the total count for playlist
  let max = data.reduce((max, value) => max > (focus === "popularity" ? value.popularity : value.count) ? max : focus === "popularity" ? value.popularity : value.count, 1);
  if (focus === "popularity") {
    max /= .3; //change max size
  }

  const min = data.reduce((min, value) => min < (focus === "popularity" ? value.popularity : value.count) ? min : focus === "popularity" ? value.popularity : value.count, max);
  src/* select */.Ys("#bubbleChart").select("svg").remove(); //ensure it doesnt redraw graph, it is used to get rid of second graph
  const width = '1000';
  const height = '1000';

  // append the svg object to the body of the page
  const svg = src/* select */.Ys("#bubbleChart").append("svg").attr("width", window.innerWidth < 600 ? 500 : width).attr("height", window.innerWidth < 600 ? 600 : height);
  //.attr("viewBox",`0 0 ${width} ${height}`)

  svg.append("defs").selectAll("pattern").data(data).enter().append("pattern").attr("id", (d, i) => i).attr("x", 0).attr("y", 0).attr("height", 1).attr("width", 1).attr("patternUnits", "objectBoundingBox").append("image").attr("x", 0).attr("y", 0).attr("height", d => normalizeRadius(focus === "popularity" ? d.popularity : d.count, min, max, window.innerWidth < 600 ? 15 : 25, window.innerWidth < 600 ? 60 : 100) * 2) // position for the image
  .attr("width", d => normalizeRadius(focus === "popularity" ? d.popularity : d.count, min, max, window.innerWidth < 600 ? 15 : 25, window.innerWidth < 600 ? 60 : 100) * 2).attr("preserveAspectRatio", "none").attr("xlink:href", d => d.image);

  // Initialize the circle: all located at the center of the svg area
  const node = svg.append("g").selectAll("circle").data(data).enter().append("circle").attr("r", d => normalizeRadius(focus === "popularity" ? d.popularity : d.count, min, max, window.innerWidth < 600 ? 15 : 25, window.innerWidth < 600 ? 60 : 100)).attr("cx", svg.node().clientWidth / 2).attr("cy", svg.node().clientHeight / 2).style("fill", (d, i) => `url(#${i})`).attr("stroke", "#1DB954").style("stroke-width", 4).on("click", onBubbleClick).on("mouseleave", onBubbleLeave)
  //@ts-ignore
  .call(src/* drag */.ohM() // call specific function when circle is dragged
  .on("start", dragstarted).on("drag", dragged).on("end", dragended));
  const tooltip = src/* select */.Ys("#bubbleChart").append("div").style("opacity", 0).style("position", "absolute").attr("class", "tooltip").style("background-color", "black").style("border-radius", "5px").style("padding", "10px").style("color", "#1DB954");

  //for background
  svg.insert("image", ":first-child").attr("href", backgroundImageURL).attr("width", svg.node().clientWidth).attr("height", svg.node().clientHeight).attr("preserveAspectRatio", "xMidYMid slice").style("opacity", 0.5);

  // Features of the forces applied to the nodes:
  const simulation = src/* forceSimulation */.A4v().force("center", src/* forceCenter */.wqt().x(svg.node().clientWidth / 2).y(svg.node().clientHeight / 2)) //set the center of gravity for the center of the gravity
  .force("charge", src/* forceManyBody */.q5i().strength(1)) // Nodes are attracted one each other of value is > 0
  .force("collide", src/* forceCollide */.Hh().strength(.5).radius(d => normalizeRadius(focus === "popularity" ? d.popularity : d.count, min, max, window.innerWidth < 600 ? 15 : 25, window.innerWidth < 600 ? 60 : 100)).iterations(1)) // Force that avoids circle overlapping
  .force("attract", src/* forceRadial */.DXo(0, svg.node().clientWidth / 2, svg.node().clientHeight / 2).strength(0.05)); //how strong the attraction it is to the center of the gravityt

  // Apply these forces to the nodes and update their positions.
  // Once the force algorithm is happy with positions ('alpha' value is low enough), simulations will stop.
  simulation.nodes(data)
  //@ts-ignore
  .on("tick", function (d) {
    //@ts-ignore
    node.attr("cx", d => d.x).attr("cy", d => d.y);
  });

  // What happens when a circle is dragged?
  //@ts-ignore
  function dragstarted(event, d) {
    if (!event.active) simulation.alphaTarget(.03).restart();
    d.fx = d.x;
    d.fy = d.y;
  }
  //@ts-ignore
  function dragged(event, d) {
    d.fx = event.x;
    d.fy = event.y;
  }
  //@ts-ignore
  function dragended(event, d) {
    if (!event.active) simulation.alphaTarget(.03);
    d.fx = null;
    d.fy = null;
  }
  function onBubbleClick(event, d) {
    tooltip.style("opacity", 1).html("artist: " + d.name + "<br />count: " + d.count + "<br />percentage: " + (d.count * 100 / totalCount).toFixed(2) + "%" + "<br />genres: " + d.genres?.join(", ") + "<br />popularity: " + d.popularity).style("left", event.pageX + "px") //event.pageX and event.pageY makes it relative position to the page for zooming + mobile
    .style("top", event.pageY + "px");
  }
  function onBubbleLeave(event, d) {
    tooltip.transition().duration(500).style("opacity", 0);
  }
}
;// CONCATENATED MODULE: ./src/Graph.tsx
//export is public functions that can be imported in from other files
// function bubblegraph grabs variable playlistID
//all the functions i write in spotifyUtils I will call it in graph


 //importing graph css
 //importing everything from bubbleGraph

//create bubble graph 
class Graph extends react.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: []
    };
  }

  //Component is UseEffect which is the backend request to the spotify api
  componentDidMount() {
    if (this.props.playlistID) {
      //grabs playlistid from props
      const data = []; //declaring the data for the playlist
      fetchPlaylistById(this.props.playlistID).then(playlist => {
        const trackInfo = playlist.map(item => ({
          id: item.track.id,
          genres: [],
          // artistIDs: item.track.artists.map(artist => artist.id)
          artistNames: item.track.artists.map(artist => artist.name),
          //grabs artist names from the artist map
          artistIds: item.track.artists.map(artist => artist.id),
          // grabs artist ids from the artist map
          artistPopularity: -1
        })); //grab the ID and Arist , and genre

        const artistIDs = trackInfo.flatMap(track => track.artistIds);
        const uniqueArtistIDs = artistIDs.filter((value, index) => value && artistIDs.indexOf(value) === index);
        if (uniqueArtistIDs.length) {
          fetchArtists(uniqueArtistIDs).then(artists => {
            artists.forEach(artist => {
              trackInfo.filter(track => track.artistIds.includes(artist.id)) //get all artist and loop through and look through track info and give me all the track from that artist
              .forEach(track => {
                track.genres.push(...artist.genres);
                track.artistPopularity = artist.popularity;
              }); //pushes the genre[] elements into trackInfo genres:[] as string []
            });

            trackInfo.forEach(track => {
              //loop through all the trackInfo
              track.artistNames.forEach(artistName => {
                //for each track grab the artist name
                const storedArtistName = data.find(trackData => trackData.name === artistName); //check the data: TrackData[] if its already in the data array
                if (storedArtistName) {
                  storedArtistName.count++; //if the artist name is in the data array increase artist name count
                } else {
                  const images = artists.find(artist => artist.name === artistName)?.images; //find the correct artist from the track info
                  let image = "https://media.istockphoto.com/id/1344687455/vector/question-sing-flat-icon-vector-illustration-isolated-on-white-background.jpg?s=612x612&w=0&k=20&c=ZU6kq0hQacI7mZoYuXTqXF8KsgNnbCRaxDm_nAIdCAw="; //if there isnt a image then default
                  if (images?.length) {
                    //if we find the artist we get the images
                    image = images[0].url; // if there are images take the image
                  }

                  data.push({
                    name: artistName,
                    count: 1,
                    image,
                    genres: track.genres,
                    popularity: track.artistPopularity
                  }); //if not in the data array then add the artist into the data: TrackData[] and add 1 and same for image
                }
              });
            });

            this.setState({
              data: data.sort((a, b) => a.count > b.count ? -1 : 1).slice(0, 100)
            });
            buildGraph(data.sort((a, b) => a.count > b.count ? -1 : 1).slice(0, 100), this.props.imageURL, "count"); //slice is viewign top 50
          });
        } else {
          //comment to do show default image
        }
      });
    }
    //build the graph using this.buildGraph
  }
  //render the svg and graph
  render() {
    return /*#__PURE__*/react.createElement("div", null, /*#__PURE__*/react.createElement("div", {
      className: "center",
      id: "bubbleChart"
    }), /*#__PURE__*/react.createElement("div", null, /*#__PURE__*/react.createElement("button", {
      onClick: () => buildGraph(this.state.data, this.props.imageURL, "count")
    }, "By Count"), /*#__PURE__*/react.createElement("button", {
      onClick: () => buildGraph(this.state.data, this.props.imageURL, "popularity")
    }, "By Popularity")));
  }
}
// EXTERNAL MODULE: ./node_modules/react-select/dist/react-select.esm.js + 52 modules
var react_select_esm = __webpack_require__("./node_modules/react-select/dist/react-select.esm.js");
;// CONCATENATED MODULE: ./src/dropdown.ts
const customStyles = {
  control: provided => ({
    ...provided,
    color: '#5A5A5A',
    backgroundColor: '#1DB954',
    borderColor: '#5A5A5A',
    borderRadius: '25px',
    fontFamily: 'Gotham Rounded, sans-serif',
    fontSize: '24px',
    width: '500px',
    // Custom width
    display: 'flex',
    justifyContent: 'center',
    // Center the text
    margin: '0 auto',
    // Center the dropdown menu on the page
    textAlign: 'center'
  }),
  option: (provided, state) => ({
    ...provided,
    backgroundColor: state.isSelected ? '#1DB954' : state.isFocused ? '#1DB954' : state.isActive ? '#1DB954' : '#191414',
    color: '#5A5A5A',
    fontFamily: 'Gotham Rounded, sans-serif',
    fontSize: '24px'
  }),
  menu: provided => ({
    ...provided,
    backgroundColor: '#191414',
    overflow: 'hidden',
    position: 'relative',
    width: '500px',
    // Custom width for options
    margin: '0 auto',
    // Center the dropdown menu on the page
    textAlign: 'center'
  }),
  menuList: provided => ({
    ...provided,
    '&::-webkit-scrollbar': {
      width: '10px'
    },
    '&::-webkit-scrollbar-track': {
      background: '#f1f1f1',
      borderRadius: '10px'
    },
    '&::-webkit-scrollbar-thumb': {
      background: '#888',
      borderRadius: '10px'
    },
    '&::-webkit-scrollbar-thumb:hover': {
      background: '#555'
    }
  }),
  singleValue: provided => ({
    ...provided,
    color: '#5A5A5A'
  }),
  placeholder: provided => ({
    ...provided,
    color: '#5A5A5A'
  })
};
;// CONCATENATED MODULE: ./src/Home.tsx
 //{} only grabs useEffect and useState from react
 // ./ because its local file 



 //importing the select drop down 

function Home() {
  const [playlists, setPlaylists] = (0,react.useState)([]); //give it the type playlistitem as []
  const [userID, setUserID] = (0,react.useState)(""); //userId store as string
  const [selectedOption, setSelectedOption] = (0,react.useState)(); //playlistId store as string
  const [loggedInUserID, setLoggedInUserID] = (0,react.useState)("");
  const resetState = () => {
    //resets everything
    logout(); //also calls logout
    setPlaylists([]);
    setUserID("");
    setSelectedOption(undefined);
    setLoggedInUserID("");
  };
  const setPlaylistDropdown = userID => {
    fetchUserPlaylists(userID) //return all the playlist items
    .then(playlists => {
      const options = playlists.map(playlist => ({
        //grabs the id of the playlist and name, and album image
        value: playlist.id,
        label: playlist.name,
        albumImg: playlist.images[0]?.url ?? "http://localhost:8080/squid.png" //mapped to the image url which is a array
      }));

      setPlaylists(options);
      setSelectedOption(options[0]); //makes it default to the 1st playlist
      const likedSongsIndex = options.findIndex(option => option.value === "likedSongs");
      if (likedSongsIndex !== -1) {
        setSelectedOption(options[likedSongsIndex]);
      }
    })
    //store them in setPlaylist variable
    .catch(error => console.error(error));
  };
  const handleUserIDChange = event => {
    //input field as soon as i type something call this function
    setUserID(event.target.value); //current target grab value
  };

  const handleUserIDSubmit = event => {
    //react.changeEvent lets the input value change the input
    event.preventDefault();
    setPlaylistDropdown(userID);
  };
  const handlePlaylistClick = (newValue, actionMeta) => {
    //button field as soon as i click on it then it calls the function
    if (newValue) {
      setSelectedOption(newValue); //current target grab value
    }
  };

  (0,react.useEffect)(() => {
    fetchProfile().then(profile => {
      if (profile?.id) {
        setLoggedInUserID(profile.id);
        setUserID(profile.id);
        setPlaylistDropdown(profile.id);
      }
    });
  }, []);

  //everytime we call authorizeLogin we will get the access token = login
  //if the user is logged in then we put his UserName and if not we put the login button
  //and we control the logout() we remove all the Information including the UserName so the if statement is no longer true
  return /*#__PURE__*/react.createElement("div", null, loggedInUserID ? /*#__PURE__*/react.createElement(react.Fragment, null, /*#__PURE__*/react.createElement("button", {
    onClick: resetState
  }, "logout"), " ", /*#__PURE__*/react.createElement("p", null, loggedInUserID)) : /*#__PURE__*/react.createElement("button", {
    onClick: async () => {
      await authorizeLogin();
    }
  }, "login"), /*#__PURE__*/react.createElement("form", {
    className: "center",
    onSubmit: handleUserIDSubmit
  }, /*#__PURE__*/react.createElement("input", {
    value: userID,
    className: "defaultInput",
    type: "text",
    name: "userID",
    placeholder: "Username",
    onChange: handleUserIDChange
  })), /*#__PURE__*/react.createElement("div", null, /*#__PURE__*/react.createElement(react_select_esm/* default */.ZP, {
    styles: customStyles,
    options: playlists,
    value: selectedOption,
    onChange: handlePlaylistClick,
    placeholder: "Spotify Playlist"
  })), selectedOption && /*#__PURE__*/react.createElement(Graph, {
    key: selectedOption.value,
    playlistID: selectedOption.value,
    imageURL: selectedOption.albumImg
  }));
}
/* harmony default export */ const src_Home = (Home);
;// CONCATENATED MODULE: ./src/Callback.tsx



const Callback = () => {
  const navigate = (0,dist.useNavigate)();
  (0,react.useEffect)(() => {
    getAccessToken().then(() => {
      navigate("/");
    });
  }, [navigate]); // 

  return /*#__PURE__*/react.createElement("div", null);
};
/* harmony default export */ const src_Callback = (Callback);
;// CONCATENATED MODULE: ./src/App.tsx
 //{} only grabs useEffect and useState from react





function App() {
  (0,react.useEffect)(() => {}, []);
  //adding the input field and save it to the variable userID and when changing it call the function handleuserid
  return /*#__PURE__*/react.createElement(dist.Routes, null, /*#__PURE__*/react.createElement(dist.Route, {
    path: "/",
    element: /*#__PURE__*/react.createElement(src_Home, null)
  }), /*#__PURE__*/react.createElement(dist.Route, {
    path: "/callback",
    element: /*#__PURE__*/react.createElement(src_Callback, null)
  }));
}
/* harmony default export */ const src_App = (App);
;// CONCATENATED MODULE: ./src/components/ConfigContext.tsx
/**
 * Provide configuration settings
 */

const ConfigContext = /*#__PURE__*/(0,react.createContext)(undefined);
/* harmony default export */ const components_ConfigContext = (ConfigContext);
;// CONCATENATED MODULE: ./public/manifest.json
const manifest_namespaceObject = JSON.parse('{"bX":"React App","mP":"#000000"}');
;// CONCATENATED MODULE: ./src/server/config.tsx
/**
 * Configuration
 */


/** Whether we're running on a local desktop or on AWS Lambda */
const isLocal = process.env.IS_LOCAL || process.env.IS_OFFLINE;

/**
 * Configuration Options
 *
 * IMPORTANT:
 * The config is injected into the client (browser) and accessible through the {@link useConfig}
 * hook. However, due to this behavior, it is important NOT to expose any sensitive information
 * such as passwords or tokens through the config.
 */
const config = {
  /** Application Config */
  app: {
    /** Name of the app is loaded from the `manifest.json` */
    TITLE: manifest_namespaceObject.bX,
    /** Theme is also loaded from the `manifest.json` */
    THEME_COLOR: manifest_namespaceObject.mP,
    /** URL to our public API Gateway endpoint */
    URL: isLocal ? `http://localhost:3000` : String(process.env.APIGATEWAY_URL),
    /** Where the bundled distribution files (`main.js`, `main.css`) are hosted */
    DIST_URL: isLocal ? "http://localhost:8080" : String(process.env.APP_DIST_URL),
    /** Where the contents of the `public` folder are hosted (might be the same as `config.app.DIST_URL`) */
    PUBLIC_URL: isLocal ? "http://localhost:8080" : String(process.env.APP_PUBLIC_URL)
  }
};
/* harmony default export */ const server_config = (config);
;// CONCATENATED MODULE: ./src/server/html.tsx
/**
 * This HTML file acts as a template that we insert all our generated
 * application code into before sending it to the client as regular HTML.
 * Note we're returning a template string from this function.
 */
const html = ({
  stats,
  content,
  config,
  css = ''
}) => `<!DOCTYPE html>
  <html lang="en">
    <head>
      <meta charset="utf-8" />
      <meta name="viewport" content="minimum-scale=1, initial-scale=1, width=device-width" />
      <meta name="theme-color" content="${config.app.THEME_COLOR}" />
      <title>${config.app.TITLE}</title>
      <link rel="manifest" href="${config.app.PUBLIC_URL}/manifest.json" />
      <link rel="shortcut icon" href="${config.app.PUBLIC_URL}/favicon.ico" />
      ${stats.styles.map(filename => `<link rel="stylesheet" href="${config.app.DIST_URL}/${filename}" />`).join('\n')}
      <style id="jss-server-side">${css}</style>
      <script id="config-server-side">
        window.__CONFIG__ = ${JSON.stringify(config)};
      </script>
    </head>
    <body>
      <div id="root">${content}</div>
      ${stats.scripts.map(filename => `<script src="${config.app.DIST_URL}/${filename}" crossorigin></script>`).join('\n')}
    </body>
  </html>`;
/* harmony default export */ const server_html = (html);
// EXTERNAL MODULE: ./node_modules/react-router-dom/server.js
var server = __webpack_require__("./node_modules/react-router-dom/server.js");
;// CONCATENATED MODULE: ./src/server/render.tsx
/**
 * Server Side Rendering
 */









/**
 * Server-side rendering
 */
async function render(event) {
  // The stats are generated by the Webpack Stats Plugin (`webpack-stats-plugin`)
  const stats = await __webpack_require__.e(/* import() */ 277).then(__webpack_require__.t.bind(__webpack_require__, "./dist/stats.json", 19));
  const content = (0,server_node/* renderToString */.Dq)( /*#__PURE__*/react.createElement(components_ConfigContext.Provider, {
    value: server_config
  }, /*#__PURE__*/react.createElement(server/* StaticRouter */.gx, {
    basename: "/",
    location: event.path
  }, /*#__PURE__*/react.createElement(src_App, null))));
  return server_html({
    stats,
    content,
    config: server_config
  });
}

/***/ })

};
;
//# sourceMappingURL=513.js.map