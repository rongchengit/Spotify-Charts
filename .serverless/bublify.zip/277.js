"use strict";
exports.id = 277;
exports.ids = [277];
exports.modules = {

/***/ "./dist/stats.json":
/***/ ((module) => {

module.exports = JSON.parse('{"scripts":["main.eaaccb74.js","runtime.84a90e91.js","vendor.ec173103.js","components.2f1e43ef.js"],"styles":["main.931c08e0.css"]}');

/***/ })

};
;