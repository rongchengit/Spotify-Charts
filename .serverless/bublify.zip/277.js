"use strict";
exports.id = 277;
exports.ids = [277];
exports.modules = {

/***/ "./dist/stats.json":
/***/ ((module) => {

module.exports = JSON.parse('{"scripts":["main.04c99649.js","runtime.835f6764.js","vendor.ec173103.js","components.2f1e43ef.js"],"styles":["main.58537cca.css"]}');

/***/ })

};
;